﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AEM01.Models
{
    public class Platform
    {
        [Key]
        public int ID { get; set; }
        [Required]
        public string UniqueName { get; set; }
        [Required]
        public decimal Latitude { get; set; }
        [Required]
        public decimal Longitude { get; set; }
        [Required]
        public DateTime CreatedAt { get; set; }
        [Required]
        public DateTime UpdatedAt { get; set; }
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]

    }
}
