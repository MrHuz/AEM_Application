﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using AEM01.Models;

namespace AEM01.Pages.Wells
{
    public class DeleteModel : PageModel
    {
        private readonly AEM01.Models.IINVdbContext _context;

        public DeleteModel(AEM01.Models.IINVdbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public WellTable WellTable { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            WellTable = await _context.WellTable.FirstOrDefaultAsync(m => m.ID == id);

            if (WellTable == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            WellTable = await _context.WellTable.FindAsync(id);

            if (WellTable != null)
            {
                _context.WellTable.Remove(WellTable);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
