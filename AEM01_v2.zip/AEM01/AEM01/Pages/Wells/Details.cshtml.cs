﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using AEM01.Models;

namespace AEM01.Pages.Wells
{
    public class DetailsModel : PageModel
    {
        private readonly AEM01.Models.IINVdbContext _context;

        public DetailsModel(AEM01.Models.IINVdbContext context)
        {
            _context = context;
        }

        public WellTable WellTable { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            WellTable = await _context.WellTable.FirstOrDefaultAsync(m => m.ID == id);

            if (WellTable == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
