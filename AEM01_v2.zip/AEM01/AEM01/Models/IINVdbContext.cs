﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace AEM01.Models
{
    public class IINVdbContext: DbContext
    {
        public IINVdbContext(DbContextOptions<IINVdbContext> options)
            : base(options)
        {
        }

        public DbSet<AEM01.Models.Platform> PlatformWell { get; set; }
        public DbSet<AEM01.Models.WellTable> WellTable { get; set; }
    }
}
